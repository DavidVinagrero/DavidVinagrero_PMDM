package com.example.ejercicio_empresa.model

class Empleado(
    var nombre: String,
    var apellido: String,
    var correo: String,
    var edad: Int,
    var puesto: String
) {
}